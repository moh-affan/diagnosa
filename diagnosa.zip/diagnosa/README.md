# diagnosa

Tugas Akhir Fajri Yuliana

## DIAGNOSA PENYAKIT GIGI DAN MULUT

Aplikasi berbasis mobile yang mengadopsi sistem pakar untuk mendiagnosa berbagai macam gejala-gejala penyakit gigi dan mulut

Metode yang digunakan : Forward Chaining

